'use strict';

/* ── Side-effect imports (CSS injection, character styles) ──────── */
import './character.js';

/* ── Module imports ────────────────────────────────────────────── */
import { currentShell, getDashboardRoot, isPlayDashboardDoc } from './shell.js';
import { formatNextTierGapHeadline, roundDebtTierBandPctClient, debtTierBandBarDisplay, syncDebtTierBandDebugOverlay } from './format.js';
import { stewardApiUrl } from './api.js';
import { TIER_META, TIER_FLOW } from './tiers.js';
import { buildSteward } from './character.js';
import { startDashboardOnboarding } from './onboarding.js';
import { resetPlayGame } from './commitment.js';
import { initDashboardBoot, manualRefresh } from './boot.js';
import { mountPlayShell } from './views/play.js';
import { loadCharacterTemplate } from './template-loader.js';

/* ── Window exports (for inline onclick handlers in HTML) ──────── */
window.manualRefresh = manualRefresh;
window.formatNextTierGapHeadline = formatNextTierGapHeadline;
window.startDashboardOnboarding = startDashboardOnboarding;
window.resetPlayGame = resetPlayGame;
window.TIER_META = TIER_META;
window.stewardTierMeta = TIER_META;
window.stewardTierFlow = TIER_FLOW;
window.buildSteward = buildSteward;
window.roundDebtTierBandPctClient = roundDebtTierBandPctClient;
window.debtTierBandBarDisplay = debtTierBandBarDisplay;
window.syncDebtTierBandDebugOverlay = syncDebtTierBandDebugOverlay;
window.stewardApiUrl = stewardApiUrl;

/* ── Init ──────────────────────────────────────────────────────── */
async function init() {
  const shell = currentShell();

  if (shell === 'play') {
    /* ── Play shell: JS-built DOM (remake architecture) ──────── */
    const root = document.getElementById('app-root');
    if (!root) return;

    mountPlayShell(root);
    document.title = 'Steward | Play';
    document.body.dataset.stewardBuild = 'remake';
    console.info('Steward: remake build active');

    await loadCharacterTemplate();

    if (typeof window !== 'undefined') {
      try {
        if (new URLSearchParams(window.location.search).has('reset')) {
          resetPlayGame();
          window.history.replaceState(null, '', window.location.pathname);
        }
      } catch (_) {}
    }

    const loadingText = document.querySelector('.loading-text');
    if (loadingText) loadingText.textContent = 'Pulling your financial data\u2026';

    initDashboardBoot();
  } else if (getDashboardRoot()) {
    /* ── Classic / vNext / other shells: original static HTML ── */
    if (document.getElementById('dashboard-vnext')) {
      document.title = 'Steward | The climb (preview)';
    } else {
      document.title = 'Steward | Financial Dashboard';
    }

    if (typeof window !== 'undefined') {
      try {
        if (new URLSearchParams(window.location.search).has('reset')) {
          resetPlayGame();
          window.history.replaceState(null, '', window.location.pathname);
        }
      } catch (_) {}
    }

    const loadingText = document.querySelector('.loading-text');
    if (loadingText) loadingText.textContent = 'Pulling your financial data...';

    initDashboardBoot();
  }
}

init();
