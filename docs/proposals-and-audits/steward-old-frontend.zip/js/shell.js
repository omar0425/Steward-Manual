'use strict';

/**
 * Shell detection — URL path for /play, DOM IDs for classic/vnext.
 *
 * /play uses a minimal HTML shell where #dashboard-play is built by JS,
 * so we detect it via URL path. Classic and vNext still have their DOM IDs
 * in static HTML, so DOM-based detection works there.
 */

export function currentShell() {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (path === '/play')     return 'play';
  if (path === '/classic')  return 'classic';
  if (path === '/showcase') return 'showcase';
  return 'vnext';
}

/** Live dashboard (`#dashboard`), stable play (`#dashboard-play`), or merged preview (`#dashboard-vnext`). */
export function getDashboardRoot() {
  return (
    document.getElementById('dashboard-play') ||
    document.getElementById('dashboard') ||
    document.getElementById('dashboard-vnext')
  );
}

/** Classic shell (`/classic` → index.html) exposes `#dashboard`; vNext uses `#dashboard-vnext` only. */
export function isClassicDashboardDoc() {
  return currentShell() === 'classic';
}

/** Stable play shell (`/play` → play.html). */
export function isPlayDashboardDoc() {
  return currentShell() === 'play';
}

/** Classic or play: same hero / off-screen board sentinel shape (not vNext). */
export function isClassicLayoutDashboardDoc() {
  return isClassicDashboardDoc() || isPlayDashboardDoc();
}
