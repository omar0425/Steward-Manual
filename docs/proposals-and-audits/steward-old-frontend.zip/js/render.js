'use strict';

import { TIER_FLOW, TIER_META, tierBehaviorLine } from './tiers.js';
import { isClassicLayoutDashboardDoc } from './shell.js';
import {
  formatRunway, fmtDollar, fmtDate, fmtSignedDollar,
  formatNetWorthValue, formatNextTierGapHeadline, formatNextTierGapBoardAmount,
  formatNextTierGapMoneyPrefix, nextMoveGuidance,
  TOOLTIP_ASSET_RUNWAY_YNAB, TOOLTIP_LIQUID_CUSHION_RUNWAY,
  WEALTHY_EXPOSED_HERO_PRIMARY,
  formatHeroBreathingRoomLine,
  formatBoardRunwayHelperLine, liquidityGuardExplanation, buildLiquidityPillTooltip,
  formatPaidDownDisplay, cumulativePaidDownFromStats, lifetimeProgressPctFromCumulative,
  paidDownDetailTooltip, formatClimbNetChangeDollars,
  fmtSignedDebtDelta, formatLastPullAccountRow, formatNetThisTurnLine,
  lastPullAccountRowsFromStats,
  debtTierBandBarDisplay, syncDebtTierBandDebugOverlay,
  snapshotPaydownWindow, snapshotPaceIsNoisy, snapshotDeltaSinceOldest,
  paceQualitative, formatApproxDurationFromMonths, timeAgo,
} from './format.js';
import { upgradeDashboardLayout, applyDashboardTheme, renderTierRail, setupHeroInteraction } from './layout.js';
import { mountHeroCharacter } from './character.js';

let lastRenderedCumulativePaidDown = null;

function renderBrokerageFootnote(brokerage, stats) {
  const sub = document.getElementById('stat-brok-sub');
  if (!sub) return;

  if (!stats.brokerageEnabled) {
    sub.hidden = true;
    sub.textContent = '';
    sub.classList.remove('is-warn');
    return;
  }

  if (!brokerage || brokerage.fetchFailed) {
    sub.hidden = false;
    sub.classList.add('is-warn');
    sub.textContent = 'Could not load brokerage summary from the server.';
    return;
  }

  if (brokerage.connected === false) {
    sub.hidden = true;
    sub.textContent = '';
    sub.classList.remove('is-warn');
    return;
  }

  if (brokerage.lastError && brokerage.lastError.message) {
    sub.hidden = false;
    const infoOnly = brokerage.lastError.code === 'NOT_YET_SYNCED';
    sub.classList.toggle('is-warn', !infoOnly);
    sub.textContent = brokerage.lastError.message;
    return;
  }

  sub.classList.remove('is-warn');
  const parts = [];
  if (brokerage.lastSuccessAt) {
    parts.push(`Last sync ${fmtDate(brokerage.lastSuccessAt)}`);
  }
  const c = brokerage.cash;
  const h = brokerage.holdingsValue;
  if (brokerage.lastSuccessAt) {
    parts.push(`Cash ${fmtDollar(c)} · Holdings ${fmtDollar(h)}`);
  }
  if (brokerage.lastSuccessAt && Number.isFinite(brokerage.dayChange)) {
    const pctStr = Number.isFinite(brokerage.dayChangePct)
      ? ` (${brokerage.dayChangePct >= 0 ? '+' : ''}${brokerage.dayChangePct.toFixed(2)}%)`
      : '';
    parts.push(`Today ${fmtSignedDollar(brokerage.dayChange)}${pctStr}`);
  }
  if (Number.isFinite(brokerage.unrealizedGainLoss) && brokerage.unrealizedGainLoss !== 0) {
    parts.push(`Unrealized ${fmtSignedDollar(brokerage.unrealizedGainLoss)}`);
  }

  sub.textContent = parts.filter(Boolean).join(' · ');
  sub.hidden = !sub.textContent;
}

const VNEXT_HERO_TURN_ACCOUNTS_TOP = 3;

/**
 * vNext only: top account deltas under “Your climb” (same stats as progress module; no extra fetch).
 */
function fillVnextHeroTurnAccounts(stats) {
  const root = document.getElementById('dashboard-vnext');
  const wrap = document.getElementById('vnext-hero-turn-accounts');
  const listEl = document.getElementById('vnext-hero-turn-accounts-list');
  const netEl = document.getElementById('vnext-hero-turn-accounts-net');
  if (!root || !wrap || !listEl || !netEl) return;

  const story = root.querySelector('.hero-story-column');
  const strip = story?.querySelector('.hero-context-strip');
  if (strip) {
    strip.insertAdjacentElement('afterend', wrap);
  }

  const { accountLines, ndVal, pdVal } = lastPullAccountRowsFromStats(stats);
  const show = accountLines.length > 0 || ndVal > 0 || pdVal > 0;
  if (!show) {
    listEl.textContent = '';
    netEl.textContent = '';
    wrap.hidden = true;
    return;
  }

  const netThisTurn =
    accountLines.length > 0
      ? accountLines.reduce((s, r) => s + Number(r.delta), 0)
      : ndVal - pdVal;

  listEl.textContent = '';
  if (accountLines.length > 0) {
    const top = accountLines
      .slice()
      .sort((a, b) => Math.abs(Number(b.delta)) - Math.abs(Number(a.delta)))
      .slice(0, VNEXT_HERO_TURN_ACCOUNTS_TOP);
    for (const r of top) {
      const li = document.createElement('li');
      li.textContent = formatLastPullAccountRow(r);
      listEl.appendChild(li);
    }
  }

  netEl.textContent = formatNetThisTurnLine(netThisTurn);
  wrap.hidden = false;
}

function fillProgressNarrative({
  nextTier,
  snapshots,
  theme,
  stability,
  debtSync,
  meta,
  stats,
  suspectedRestructure,
}) {
  const restructureFlag =
    suspectedRestructure === true || !!(debtSync && debtSync.suspected_restructure);
  const restructureEl = document.getElementById('progress-restructure-note');
  if (restructureEl) {
    if (restructureFlag) {
      restructureEl.textContent =
        'This may reflect a refinance or account change, not a true payoff.';
      restructureEl.hidden = false;
    } else {
      restructureEl.textContent = '';
      restructureEl.hidden = true;
    }
  }

  const staleEl = document.getElementById('progress-stale-note');
  if (staleEl) {
    const fr = meta && meta.freshness;
    const stale = typeof fr === 'string' && fr.startsWith('Stale');
    if (stale) {
      staleEl.textContent =
        'Data may be outdated — refresh before making decisions.';
      staleEl.hidden = false;
    } else {
      staleEl.textContent = '';
      staleEl.hidden = true;
    }
  }

  const lead = document.getElementById('progress-story-lead');
  const deltaEl = document.getElementById('progress-story-delta');
  const paceEl = document.getElementById('progress-story-pace');
  const hintEl = document.getElementById('progress-story-hint');
  const projEl = document.getElementById('progress-story-projection');
  const projDebtFreeEl = document.getElementById('progress-story-projection-debtfree');
  if (!lead || !deltaEl || !paceEl || !hintEl) return;

  const lifetimeEl = document.getElementById('progress-lifetime-climb');
  const lastPullWrap = document.getElementById('climb-last-pull-summary');
  const lastPullAccountsEl = document.getElementById('progress-last-pull-accounts');
  const lastPullNetEl = document.getElementById('progress-last-pull-net-line');
  const lastPullLifetimeEl = document.getElementById('progress-last-pull-lifetime-line');

  if (nextTier) {
    lead.textContent =
      'Recent movement from snapshot history (below) and pace — not the same as lifetime % (see lifetime line when present).';
  } else {
    lead.textContent =
      'Final payoff stage — no dollars left to the next threshold. Protect the floor you fought for.';
  }

  if (lifetimeEl && stats) {
    const baseline = Number(stats.climbBaselineDebt);
    const paid = cumulativePaidDownFromStats(stats);
    const pct = lifetimeProgressPctFromCumulative(stats);
    if (Number.isFinite(baseline) && baseline > 0) {
      lifetimeEl.textContent = `Lifetime: ${pct}% of baseline (${fmtDollar(baseline)}) — ${fmtDollar(
        paid,
      )} cumulative paydown since tracking. New debt does not reduce this.`;
      lifetimeEl.hidden = false;
    } else {
      lifetimeEl.textContent = '';
      lifetimeEl.hidden = true;
    }
  } else if (lifetimeEl) {
    lifetimeEl.textContent = '';
    lifetimeEl.hidden = true;
  }

  if (lastPullWrap && lastPullAccountsEl && lastPullNetEl && lastPullLifetimeEl && stats) {
    const { accountLines, ndVal, pdVal } = lastPullAccountRowsFromStats(stats);
    const show = accountLines.length > 0 || ndVal > 0 || pdVal > 0;
    if (show) {
      lastPullAccountsEl.textContent = '';
      if (accountLines.length > 0) {
        for (const r of accountLines) {
          const row = document.createElement('p');
          row.className = 'progress-hint climb-last-pull-line climb-last-pull-account-line';
          row.textContent = formatLastPullAccountRow(r);
          lastPullAccountsEl.appendChild(row);
        }
      } else {
        const rowPd = document.createElement('p');
        rowPd.className = 'progress-hint climb-last-pull-line climb-last-pull-account-line';
        rowPd.textContent = `Paydown: ${fmtDollar(pdVal)}`;
        const rowNd = document.createElement('p');
        rowNd.className = 'progress-hint climb-last-pull-line climb-last-pull-account-line';
        rowNd.textContent = `New debt: ${fmtDollar(ndVal)}`;
        lastPullAccountsEl.appendChild(rowPd);
        lastPullAccountsEl.appendChild(rowNd);
      }
      const netThisTurn =
        accountLines.length > 0
          ? accountLines.reduce((s, r) => s + Number(r.delta), 0)
          : ndVal - pdVal;
      lastPullNetEl.textContent = formatNetThisTurnLine(netThisTurn);
      lastPullLifetimeEl.textContent = `Lifetime paid down: ${fmtDollar(
        cumulativePaidDownFromStats(stats),
      )}`;
      lastPullWrap.hidden = false;
    } else {
      lastPullAccountsEl.textContent = '';
      lastPullNetEl.textContent = '';
      lastPullLifetimeEl.textContent = '';
      lastPullWrap.hidden = true;
    }
  } else if (lastPullWrap) {
    lastPullWrap.hidden = true;
  }

  const { delta, oldest } = snapshotDeltaSinceOldest(snapshots);
  if (!snapshots || snapshots.length < 2) {
    deltaEl.textContent = 'Need at least two snapshots on file to measure change over time.';
  } else if (delta > 0) {
    deltaEl.textContent = `Snapshot window: aggregate debt down about ${fmtDollar(delta)} since your earliest snapshot (${timeAgo(
      oldest.pulled_at,
    )}). This is YNAB total debt, not your cumulative paydown line.`;
  } else if (delta < 0) {
    deltaEl.textContent = `Snapshot window: aggregate debt up ${fmtDollar(-delta)} since your earliest snapshot (often borrowing or new accounts). Cumulative paydown does not decrease from this.`;
  } else {
    deltaEl.textContent =
      'Flat since your earliest snapshot — the next pull should show direction. (Snapshot aggregate, not cumulative paydown.)';
  }

  const { avgMonthly, windowMonths } = snapshotPaydownWindow(snapshots);
  let paceText = '';
  if (!snapshots || snapshots.length < 2) {
    paceText = 'Not enough snapshots to judge monthly pace.';
  } else if (windowMonths < 0.08) {
    paceText = 'Pulls are very close in time — more calendar span is needed to judge pace.';
  } else {
    paceText = paceQualitative(avgMonthly);
  }
  paceEl.textContent = paceText;

  const noisy = snapshotPaceIsNoisy(snapshots);
  const fr = meta && meta.freshness;
  const stale = typeof fr === 'string' && fr.startsWith('Stale');
  const shortHistory = !snapshots || snapshots.length < 2 || windowMonths < 0.08;
  if (projEl && projDebtFreeEl) {
    projEl.hidden = false;
    projDebtFreeEl.hidden = true;
    projDebtFreeEl.textContent = '';
    if (stale) {
      projEl.textContent = 'Data is outdated — refresh to see a payoff estimate.';
    } else if (restructureFlag) {
      projEl.textContent = 'Recent account changes make the payoff estimate unreliable.';
    } else if (shortHistory) {
      projEl.textContent = 'Need more history to estimate payoff timing.';
    } else if (avgMonthly == null || avgMonthly <= 0) {
      projEl.textContent = "Debt isn't decreasing yet — no payoff estimate.";
    } else if (noisy) {
      projEl.textContent = 'Recent progress is uneven — payoff timing is unclear.';
    } else {
      const debtRem = Number(stats && stats.debtRemaining);
      const hasDebt = Number.isFinite(debtRem) && debtRem > 0;
      const gapN = nextTier ? Number(nextTier.gapDollars) : NaN;
      let line1 = '';
      if (nextTier && Number.isFinite(gapN) && gapN > 0) {
        const mNext = gapN / avgMonthly;
        const d1 = formatApproxDurationFromMonths(mNext);
        if (d1) line1 = `At this pace: ${d1} to next stage.`;
      }
      let line2 = '';
      if (hasDebt) {
        const mFree = debtRem / avgMonthly;
        const d2 = formatApproxDurationFromMonths(mFree);
        const gapCloseToDebt = Number.isFinite(gapN) && Math.abs(debtRem - gapN) < 2;
        const monthsClose =
          Number.isFinite(gapN) && gapN > 0 && Math.abs(mFree - gapN / avgMonthly) < 0.15;
        const redundant = line1 && gapCloseToDebt && monthsClose;
        if (d2 && !redundant) line2 = `Debt-free at this pace: ${d2}.`;
      }
      if (line1 || line2) {
        projEl.textContent = line1;
        projEl.hidden = !line1;
        projDebtFreeEl.textContent = line2;
        projDebtFreeEl.hidden = !line2;
      } else {
        projEl.textContent = '';
        projEl.hidden = true;
      }
    }
  }

  if (nextTier && nextTier.gapDollars > 0) {
    const g = Number(nextTier.gapDollars);
    if (Number.isFinite(g) && fmtDollar(g) === '$0') {
      hintEl.textContent =
        'Less than $1 of paydown reaches the next payoff-stage threshold (illustrative).';
    } else {
      hintEl.textContent =
        `Roughly ${fmtDollar(g / 12)}/mo for twelve months would close the gap to the next payoff stage (illustrative).`;
    }
  } else {
    const skipWealthyExpansionCue =
      !nextTier && theme.id === 'wealthy' && stability?.id === 'exposed';
    hintEl.textContent = nextTier ? '' : (skipWealthyExpansionCue ? '' : (theme.cue || ''));
  }

  const rec = stability?.narrative?.recommend;
  if (rec) {
    hintEl.textContent = hintEl.textContent ? `${hintEl.textContent} ${rec}` : rec;
  }
}

export function render(status, snapshots, brokerage) {
  if (!status.ready) return;

  upgradeDashboardLayout();

  const { tier, stats, nextTier, meta, stability } = status;
  const theme = TIER_META[tier.id] || TIER_FLOW[0];
  /* If API omits stability, assume middle liquidity band (id stabilizing, label Steady). */
  const stab = stability || { id: 'stabilizing', label: 'Steady', narrative: {} };
  const classicDoc = isClassicLayoutDashboardDoc();
  const runwayText = formatRunway(stats.monthsAhead);
  const netWorthText = formatNetWorthValue(stats.netWorth);
  const paidShown = cumulativePaidDownFromStats(stats);
  const paidTooltip = paidDownDetailTooltip(stats);
  const paidDisplay = formatPaidDownDisplay(paidShown, paidTooltip);
  /* Dollars headline = primary product signal; in-band bar width uses inBandBarDisplayPct only (secondary). */
  const { rawPct: tierBarRawInBandPct, displayPct: inBandBarDisplayPct } = debtTierBandBarDisplay(stats);
  syncDebtTierBandDebugOverlay(stats, tierBarRawInBandPct, inBandBarDisplayPct);

  applyDashboardTheme(tier.id, stab.id);
  setupHeroInteraction();
  renderTierRail(tier.id, nextTier?.id);
  mountHeroCharacter(tier.id);

  const heroBadge = document.getElementById('hero-badge');
  const heroPhase = document.getElementById('hero-phase-pill');
  const heroLive = document.getElementById('hero-live-pill');
  const heroStabPill = document.getElementById('hero-stability-pill');
  const showcaseLink = document.querySelector('.showcase-link');

  if (heroBadge) {
    heroBadge.textContent = classicDoc
      ? `Stage ${tier.badge} — ${tier.label}`
      : `Payoff stage: ${tier.badge} · ${tier.label}`;
  }
  /* Breathing room: visible wording from stab.label (Steady when stab.id is stabilizing); theme class uses id → .is-stabilizing. */
  if (heroStabPill) {
    heroStabPill.textContent = classicDoc ? `Runway: ${stab.label}` : `Breathing room: ${stab.label}`;
    heroStabPill.className = 'hero-stability-pill';
    heroStabPill.classList.add(`is-${stab.id}`);
    heroStabPill.title = buildLiquidityPillTooltip(stab);
  }

  const heroAxesHint = document.getElementById('hero-axes-hint');
  if (heroAxesHint) {
    heroAxesHint.textContent = classicDoc
      ? 'This card tracks what it takes to clear this stage.'
      : 'The headline on the card is your escape gap. The thin bar is only your position inside this stage—not breathing room or total debt paid down.';
  }
  const heroLiqRunwayEl = document.getElementById('hero-liquidity-runway');
  if (heroLiqRunwayEl) {
    const rw = formatHeroBreathingRoomLine(stab, classicDoc);
    heroLiqRunwayEl.textContent = rw || '';
    heroLiqRunwayEl.hidden = !rw;
    heroLiqRunwayEl.title = TOOLTIP_LIQUID_CUSHION_RUNWAY;
  }
  const heroGuardEl = document.getElementById('hero-guard-hint');
  if (heroGuardEl) {
    const gMsg = liquidityGuardExplanation(stab.scoring && stab.scoring.guard);
    heroGuardEl.textContent = gMsg || '';
    heroGuardEl.hidden = !gMsg;
  }
  if (heroPhase) heroPhase.textContent = `${theme.phase} phase`;
  if (heroLive) {
    heroLive.textContent = meta.freshness;
    heroLive.className = 'hero-live-pill';
    if (meta.freshness.startsWith('Stale')) heroLive.classList.add('is-stale');
    else if (meta.freshness.includes('h ago')) heroLive.classList.add('is-aged');
  }
  if (showcaseLink && classicDoc) showcaseLink.textContent = 'View all 10 stages';
  else if (showcaseLink) showcaseLink.textContent = 'Explore all 10 debt tiers';

  document.getElementById('hero-tier-label').textContent = tier.label;
  const heroBehaviorEl = document.getElementById('hero-tier-behavior');
  if (heroBehaviorEl) {
    let behaviorLine = tierBehaviorLine(tier.id);
    if (classicDoc && tier.id === 'rock_bottom') {
      behaviorLine = 'Cut the balance. Protect cash.';
    }
    heroBehaviorEl.textContent = behaviorLine;
    heroBehaviorEl.hidden = !behaviorLine;
  }

  const heroNextActionEl = document.getElementById('hero-next-action');
  if (heroNextActionEl) {
    if (!classicDoc) {
      heroNextActionEl.textContent = '';
      heroNextActionEl.hidden = true;
    } else if (nextTier) {
      const g = Number(nextTier.gapDollars);
      if (Number.isFinite(g) && g > 0) {
        const money = formatNextTierGapMoneyPrefix(g);
        heroNextActionEl.textContent = `Next move: free up ${money}`;
        heroNextActionEl.hidden = false;
      } else {
        heroNextActionEl.textContent = '';
        heroNextActionEl.hidden = true;
      }
    } else {
      heroNextActionEl.textContent = '';
      heroNextActionEl.hidden = true;
    }
  }

  const narr = stab.narrative || {};
  const isWealthyExposed = tier.id === 'wealthy' && stab.id === 'exposed';
  const heroTierCopyEl = document.getElementById('hero-tier-copy');
  if (heroTierCopyEl) {
    if (isWealthyExposed) {
      heroTierCopyEl.textContent = WEALTHY_EXPOSED_HERO_PRIMARY;
    } else if (classicDoc && tier.id === 'rock_bottom') {
      heroTierCopyEl.textContent = "You're in the hole. The meter is running.";
    } else {
      heroTierCopyEl.textContent = tier.copy;
    }
  }
  const stabilityLeadEl = document.getElementById('hero-stability-lead');
  if (stabilityLeadEl) {
    let lead = narr.lead || '';
    if (
      classicDoc &&
      lead === 'Debt is still very large — and cash safety is not yet matching the risk.'
    ) {
      lead = "Debt is still high, and cash safety isn't there yet.";
    }
    stabilityLeadEl.textContent = lead;
  }
  const moodEl = document.getElementById('hero-mood-copy');
  if (moodEl) {
    if (isWealthyExposed) {
      moodEl.textContent = narr.mood;
    } else if (classicDoc && tier.id === 'rock_bottom') {
      moodEl.textContent =
        'Prioritize cash and minimums. Every dollar freed up moves you forward. Breathing room has to rise alongside payoff.';
    } else {
      moodEl.textContent = [theme.cue, narr.mood].filter(Boolean).join(' ');
    }
  }
  const heroPaid = document.getElementById('hero-stat-paid');
  if (heroPaid) {
    heroPaid.textContent = paidDisplay.text;
    heroPaid.title = paidDisplay.title;
  }
  const heroClimbSummary = document.getElementById('hero-climb-summary');
  const heroLineNew = document.getElementById('hero-climb-line-new-debt');
  const heroLinePd = document.getElementById('hero-climb-line-paydown');
  const heroLineNet = document.getElementById('hero-climb-line-net');
  if (heroClimbSummary && heroLineNew && heroLinePd && heroLineNet) {
    const addedRaw = Number(stats.cumulativeNewDebtAdded);
    if (Number.isFinite(addedRaw) && addedRaw > 0) {
      const paid = cumulativePaidDownFromStats(stats);
      const netDelta = addedRaw - paid;
      if (classicDoc) {
        heroLineNew.textContent = `Added this turn: ${fmtDollar(Math.round(addedRaw))}`;
        heroLinePd.textContent = `Paid down: ${fmtDollar(paid)}`;
        heroLineNet.textContent = `Net: ${fmtSignedDebtDelta(netDelta)} debt`;
      } else {
        heroLineNew.textContent = `New debt tracked: ${fmtDollar(Math.round(addedRaw))}`;
        heroLinePd.textContent = `Paydown (cumulative): ${fmtDollar(paid)}`;
        heroLineNet.textContent = `Net change: ${formatClimbNetChangeDollars(addedRaw, paid)}`;
      }
      heroClimbSummary.hidden = false;
    } else {
      heroLineNew.textContent = '';
      heroLinePd.textContent = '';
      heroLineNet.textContent = '';
      heroClimbSummary.hidden = true;
    }
  }
  const heroPaidLabel = document.querySelector('.hero-context-strip .hero-context-cell:first-child .hero-context-label');
  if (heroPaidLabel) {
    heroPaidLabel.textContent = 'Your climb';
  }
  const heroRunway = document.getElementById('hero-stat-runway');
  if (heroRunway) {
    heroRunway.textContent = runwayText;
    heroRunway.title = TOOLTIP_ASSET_RUNWAY_YNAB;
  }

  document.getElementById('card-badge-chip').textContent = tier.badge;
  document.getElementById('card-tier-name').textContent = tier.label;
  const gapHeadline = formatNextTierGapHeadline(nextTier, tier);
  const boardGapAmount = formatNextTierGapBoardAmount(nextTier);
  document.getElementById('card-tier-gap-headline').textContent = gapHeadline;

  const cardBarTrack = document.querySelector('.card-bar-track');
  if (cardBarTrack) {
    cardBarTrack.title =
      'Thin bar: position inside this payoff stage only. The prominent line above states your dollar gap to escape this stage.';
  }
  document.getElementById('card-bar-fill').style.width = `${inBandBarDisplayPct}%`;
  const cardBarInbandPct = document.getElementById('card-bar-inband-pct');
  if (cardBarInbandPct) {
    cardBarInbandPct.textContent = '';
    cardBarInbandPct.hidden = true;
    cardBarInbandPct.setAttribute('aria-hidden', 'true');
  }
  document.getElementById('card-footer-debt').textContent = `${fmtDollar(stats.debtRemaining)} debt remaining`;

  document.getElementById('stat-debt-remaining').textContent = fmtDollar(stats.debtRemaining);
  const statDebtPaid = document.getElementById('stat-debt-paid');
  if (statDebtPaid) {
    statDebtPaid.textContent = paidDisplay.text;
    statDebtPaid.title = paidDisplay.title;
  }
  const statPaidLabel = document.querySelector('.board-block.board-progress .paid-label');
  if (statPaidLabel) {
    statPaidLabel.textContent = '';
  }
  const paidFeedbackEl = document.getElementById('paid-down-feedback');
  if (paidFeedbackEl) {
    const prev = lastRenderedCumulativePaidDown;
    if (prev != null && Number.isFinite(prev) && paidShown > prev) {
      paidFeedbackEl.textContent = `+${fmtDollar(paidShown - prev)} since last refresh`;
      paidFeedbackEl.hidden = false;
    } else {
      paidFeedbackEl.textContent = '';
      paidFeedbackEl.hidden = true;
    }
  }
  const boardGapLabelEl = document.getElementById('board-tier-gap-label');
  if (boardGapLabelEl) boardGapLabelEl.textContent = 'Stage gap';
  document.getElementById('board-tier-gap-headline').textContent = boardGapAmount;
  /* nextTier.nextCopy (GET /api/status) — threshold meaning line; server sends current tier copy */
  const milestoneNextEl = document.getElementById('progress-milestone-next');
  if (milestoneNextEl) {
    const milestoneCopy =
      nextTier && typeof nextTier.nextCopy === 'string' ? nextTier.nextCopy.trim() : '';
    if (milestoneCopy) {
      milestoneNextEl.textContent = milestoneCopy;
      milestoneNextEl.hidden = false;
    } else {
      milestoneNextEl.textContent = '';
      milestoneNextEl.hidden = true;
    }
  }
  const progressFill = document.getElementById('command-progress-bar-fill');
  const progressWidget = document.getElementById('command-progress-widget');
  if (progressFill) {
    progressFill.style.width = `${inBandBarDisplayPct}%`;
  }
  if (progressWidget) {
    /* Name = label + dollars headline (HTML aria-labelledby). valuetext = in-band bar only so SR does not treat % as overall payoff. */
    progressWidget.setAttribute('aria-valuenow', inBandBarDisplayPct.toFixed(1));
    progressWidget.setAttribute(
      'aria-valuetext',
      `Bar ${inBandBarDisplayPct.toFixed(1)}% through this payoff stage toward the next payoff stage—not share of total debt paid off.`,
    );
    progressWidget.title =
      'The full escape line is on the hero card. Here, "Stage gap" repeats the dollar figure only. This bar is in-stage position—not breathing room or full payoff.';
  }

  const nextMoveEl = document.getElementById('progress-next-move');
  if (nextMoveEl) {
    const cue = nextMoveGuidance(nextTier);
    nextMoveEl.textContent = cue;
    nextMoveEl.hidden = !cue;
  }

  const netWorthStat = document.getElementById('stat-net-worth');
  if (netWorthStat) {
    netWorthStat.textContent = netWorthText;
    netWorthStat.classList.toggle('is-negative', stats.netWorth < 0);
  }

  document.getElementById('stat-assets').textContent = fmtDollar(stats.totalAssets);
  const invEl = document.getElementById('stat-investments');
  if (invEl) {
    if (stats.brokerageEnabled) {
      invEl.textContent = fmtDollar(stats.investmentValue);
      invEl.classList.remove('is-muted');
      invEl.removeAttribute('title');
    } else {
      invEl.textContent = 'Not linked';
      invEl.classList.add('is-muted');
      invEl.title = 'Brokerage not linked';
    }
  }
  renderBrokerageFootnote(brokerage, stats);
  const statMonthsAhead = document.getElementById('stat-months-ahead');
  if (statMonthsAhead) {
    statMonthsAhead.textContent = runwayText;
    statMonthsAhead.title = TOOLTIP_ASSET_RUNWAY_YNAB;
  }
  document.getElementById('stat-income').textContent = fmtDollar(stats.monthlyIncome);
  document.getElementById('stat-expenses').textContent = fmtDollar(stats.monthlyExpenses);

  const tierCurrent = document.getElementById('next-tier-current');
  const tierTarget = document.getElementById('next-tier-target');
  if (tierCurrent) tierCurrent.textContent = `${tier.badge} · ${tier.label}`;
  if (tierTarget) {
    tierTarget.textContent = nextTier ? `${nextTier.badge} · ${nextTier.label}` : 'Final payoff stage';
  }

  fillProgressNarrative({
    nextTier,
    snapshots,
    theme,
    stability: stab,
    debtSync: status.debug && status.debug.debtSync,
    meta,
    stats,
    suspectedRestructure: status.suspectedRestructure,
  });

  fillVnextHeroTurnAccounts(stats);

  const boardDebtAxis = document.getElementById('board-debt-axis');
  const boardLiqPill = document.getElementById('board-liquidity-pill');
  if (boardDebtAxis) {
    boardDebtAxis.textContent = `Payoff stage: ${tier.badge} · ${tier.label}`;
    boardDebtAxis.className = 'board-stability-pill board-axis-debt';
  }
  /* Same breathing-room id/label rules as hero pill. */
  if (boardLiqPill) {
    boardLiqPill.textContent = `Breathing room: ${stab.label}`;
    boardLiqPill.className = 'board-stability-pill board-axis-liquidity';
    boardLiqPill.classList.add(`is-${stab.id}`);
    boardLiqPill.title = buildLiquidityPillTooltip(stab);
  }

  const boardAxesHint = document.getElementById('board-axes-hint');
  if (boardAxesHint) {
    boardAxesHint.textContent =
      'The escape goal is the hero headline. Below, the bar is only your position inside this stage. Breathing room is separate.';
  }

  const boardRunwayLine = document.getElementById('board-runway-line');
  if (boardRunwayLine) {
    boardRunwayLine.textContent = formatBoardRunwayHelperLine(stats.monthsAhead, stab);
    boardRunwayLine.title =
      'Two runways: breathing room is spendable-style cushion ÷ expenses (the chip). Asset runway (YNAB) is all on-budget assets ÷ expenses—often higher when investments dominate.';
  }

  const boardGuardNote = document.getElementById('board-guard-note');
  if (boardGuardNote) {
    const gMsg = liquidityGuardExplanation(stab.scoring && stab.scoring.guard);
    if (gMsg) {
      boardGuardNote.hidden = false;
      boardGuardNote.textContent = gMsg;
    } else {
      boardGuardNote.hidden = true;
      boardGuardNote.textContent = '';
    }
  }

  const boardStabNote = document.getElementById('board-stability-note');
  if (boardStabNote) {
    const invPct = Math.round(
      (stab.components && stab.components.investedWeightUsed != null ? stab.components.investedWeightUsed
        : 0.35) * 100,
    );
    const parts = [
      `How breathing room is measured: spendable-style cushion (on-budget cash-like YNAB balances, brokerage cash, and ${invPct}% of brokerage holdings) divided by your last full month of expenses in YNAB.`,
    ];
    if (stab.scoring && stab.scoring.legacyFallback) {
      parts.push('Using a broader asset estimate until the next pull; refresh when you can.');
    }
    boardStabNote.textContent = parts.join(' ');
  }

  document.getElementById('data-ynab-pulled').textContent = fmtDate(meta.ynabPulledAt);
  let brokPulledLabel = 'disabled';
  if (stats.brokerageEnabled) {
    if (brokerage && brokerage.lastSuccessAt) {
      brokPulledLabel = fmtDate(brokerage.lastSuccessAt);
    } else if (meta.brokeragePulledAt) {
      brokPulledLabel = fmtDate(meta.brokeragePulledAt);
    } else {
      brokPulledLabel = '--';
    }
  }
  document.getElementById('data-brok-pulled').textContent = brokPulledLabel;
  document.getElementById('data-next-pull').textContent = fmtDate(meta.nextScheduled);

  const freshnessBadge = document.getElementById('freshness-badge');
  freshnessBadge.textContent = meta.freshness;
  freshnessBadge.className = 'freshness-badge';
  if (meta.freshness.startsWith('Stale')) freshnessBadge.classList.add('stale');
  else if (meta.freshness.includes('h ago')) freshnessBadge.classList.add('aged');

  if (typeof window.stewardVnextEnhance === 'function') {
    window.stewardVnextEnhance({ tier, stats, nextTier, meta, stability: stab, snapshots });
  }

  lastRenderedCumulativePaidDown = paidShown;
}
