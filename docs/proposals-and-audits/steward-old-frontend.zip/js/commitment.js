'use strict';

import { stewardApiUrl, readJsonRes } from './api.js';
import { fmtDollar } from './format.js';
import { STEWARD_SESSION_META_KEY, SESSION_APP_READY_KEY } from './session.js';

/* ── First-run commitment (optional DOM: `#commitment-screen` on play.html) ─ */
const STEWARD_PROMISE_MADE_KEY = 'steward_promise_made';
const STEWARD_PROMISE_AT_KEY = 'steward_promise_made_at';
const STEWARD_PROMISE_TEXT_KEY = 'steward_promise_text';
export const DASHBOARD_ONBOARDING_KEY = 'steward_dashboard_guided_tour_v2';

export function readPromiseMadeFlag() {
  try {
    const v = localStorage.getItem(STEWARD_PROMISE_MADE_KEY);
    return v === 'true' || v === '1';
  } catch {
    return false;
  }
}

function persistPromiseAck(customText) {
  try {
    localStorage.setItem(STEWARD_PROMISE_MADE_KEY, 'true');
    localStorage.setItem(STEWARD_PROMISE_AT_KEY, new Date().toISOString());
    const t = (customText || '').trim();
    if (t) localStorage.setItem(STEWARD_PROMISE_TEXT_KEY, t);
    else localStorage.removeItem(STEWARD_PROMISE_TEXT_KEY);
  } catch (err) {
    console.warn('[commitment] could not persist', err);
  }
}

async function hydrateCommitmentDebtAmount(amountEl) {
  if (!amountEl) return;
  if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
    amountEl.textContent = '—';
    return;
  }
  try {
    const res = await fetch(stewardApiUrl('/api/status?debugDebtSync=1'));
    const data = await readJsonRes(res, '/api/status');
    if (!data || !data.ready || !data.stats) {
      amountEl.textContent = '—';
      return;
    }
    const d = Number(data.stats.debtRemaining);
    if (!Number.isFinite(d)) {
      amountEl.textContent = '—';
      return;
    }
    if (d <= 0) {
      amountEl.textContent = '$0';
      return;
    }
    amountEl.textContent = fmtDollar(d, { absOnly: true });
  } catch {
    amountEl.textContent = '—';
  }
}

export function openCommitmentGate(done) {
  const root = document.getElementById('commitment-screen');
  const amountEl = document.getElementById('commitment-debt-amount');
  const customInput = document.getElementById('commitment-custom-input');
  const btn = document.getElementById('commitment-confirm-btn');
  if (!root || !btn) {
    done();
    return;
  }

  root.removeAttribute('hidden');
  void hydrateCommitmentDebtAmount(amountEl);
  try {
    btn.focus();
  } catch (_) {
    /* ignore */
  }

  const onConfirm = () => {
    btn.removeEventListener('click', onConfirm);
    persistPromiseAck(customInput && customInput.value);
    root.setAttribute('hidden', '');
    done();
  };

  btn.addEventListener('click', onConfirm);
}

/* ── Play game reset — clears all play-only localStorage/sessionStorage ─ */
export function resetPlayGame() {
  const keys = [
    STEWARD_SESSION_META_KEY,
    STEWARD_PROMISE_MADE_KEY,
    STEWARD_PROMISE_AT_KEY,
    STEWARD_PROMISE_TEXT_KEY,
    DASHBOARD_ONBOARDING_KEY,
  ];
  try {
    keys.forEach(k => localStorage.removeItem(k));
  } catch (err) {
    console.warn('[play] reset localStorage failed', err);
  }
  try { sessionStorage.removeItem(SESSION_APP_READY_KEY); } catch (_) {}
}
if (typeof window !== 'undefined') window.resetPlayGame = resetPlayGame;

export function initPlayResetBtn() {
  const btn = document.getElementById('play-reset-btn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    if (!window.confirm('Reset game?\n\nThis clears your commitment, session history, and onboarding. Your financial data stays.')) return;
    resetPlayGame();
    window.location.href = window.location.pathname;
  });
}
