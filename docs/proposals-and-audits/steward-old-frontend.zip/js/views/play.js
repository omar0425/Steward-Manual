'use strict';

/**
 * Builds the complete /play shell DOM — same structure, same IDs, same classes
 * as play.html so the same CSS applies without changes.
 */

function el(tag, attrs, ...children) {
  const e = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'hidden' && v) { e.hidden = true; continue; }
      if (k === 'textContent') { e.textContent = v; continue; }
      if (k === 'innerHTML') { e.innerHTML = v; continue; }
      if (k.startsWith('data-')) { e.dataset[k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = v; continue; }
      if (k === 'style' && typeof v === 'string') { e.setAttribute('style', v); continue; }
      e.setAttribute(k, v);
    }
  }
  for (const child of children) {
    if (typeof child === 'string') e.appendChild(document.createTextNode(child));
    else if (child) e.appendChild(child);
  }
  return e;
}

function buildCommitmentScreen() {
  return el('div', { id: 'commitment-screen', class: 'commitment-screen', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'commitment-headline', hidden: true },
    el('div', { class: 'commitment-inner' },
      el('h1', { id: 'commitment-headline', class: 'commitment-headline' }, 'Make this real.'),
      el('p', { class: 'commitment-debt-line', id: 'commitment-debt-line', innerHTML: 'You are <span id="commitment-debt-amount">…</span> in debt.' }),
      el('div', { class: 'commitment-body' },
        el('p', null, 'This doesn\u2019t fix itself.'),
        el('p', null, 'No one is coming to save you.'),
        el('p', null, 'You either change this \u2014 or you live with it.'),
      ),
      el('blockquote', { class: 'commitment-pledge', cite: 'about:blank' },
        el('p', null, 'I\u2019m done ignoring this.'),
        el('p', null, 'I\u2019m taking control of my money.'),
      ),
      el('label', { class: 'commitment-custom-label', for: 'commitment-custom-input', innerHTML: 'Your own commitment <span class="commitment-optional">(optional)</span>' }),
      el('textarea', { id: 'commitment-custom-input', class: 'commitment-custom-input', rows: '3', maxlength: '2000', placeholder: 'Write what you need to hear \u2014 or leave blank.' }),
      el('button', { type: 'button', class: 'commitment-btn', id: 'commitment-confirm-btn' }, 'I\u2019m in'),
    ),
  );
}

function buildTopNav() {
  return el('header', { class: 'classic-top-nav app-shell play-top-nav', 'aria-label': 'Steward Play' },
    el('div', { class: 'classic-top-nav-inner' },
      el('span', { class: 'classic-nav-badge play-nav-badge' }, 'Play'),
      el('p', { class: 'play-shell-note', innerHTML: 'Stable experience \u00b7 <a href="/classic">Classic</a> \u00b7 <a href="/">Preview</a>' }),
    ),
  );
}

function buildStartGameScreen() {
  return el('div', { id: 'start-game-screen', class: 'start-game-screen', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'start-game-title' },
    el('div', { class: 'start-game-inner' },
      el('p', { class: 'start-game-brand' }, 'Steward'),
      el('h1', { id: 'start-game-title', class: 'start-game-title' }, 'Start Game'),
      el('p', { class: 'start-game-subtitle' }, 'Begin this run and track your progress.'),
      el('div', { class: 'start-game-scene-wrap' },
        el('div', { class: 'sg-balloons', 'aria-hidden': 'true' },
          el('div', { class: 'sg-balloon sg-balloon-1' }),
          el('div', { class: 'sg-balloon sg-balloon-2' }),
          el('div', { class: 'sg-balloon sg-balloon-3' }),
        ),
        el('div', { id: 'start-game-character', class: 'start-game-character', 'aria-hidden': 'true' }),
      ),
      el('p', { class: 'start-game-clock', id: 'start-game-clock', 'aria-live': 'polite' }),
      el('button', { type: 'button', class: 'start-game-btn', id: 'start-game-btn' }, 'Start Game'),
    ),
  );
}

function buildLoadingScreen() {
  return el('div', { id: 'loading-screen', class: 'loading-screen' },
    el('div', { class: 'loading-inner' },
      el('div', { class: 'loading-spinner' }),
      el('p', { class: 'loading-text' }, 'Pulling your financial data\u2026'),
    ),
  );
}

function buildErrorScreen() {
  return el('div', { id: 'app-error-screen', class: 'app-error-screen', role: 'alert', 'aria-live': 'assertive' },
    el('div', { class: 'app-error-inner' },
      el('p', { class: 'app-error-title' }, 'Couldn\u2019t load Steward'),
      el('p', { class: 'app-error-text', id: 'app-error-text' }),
      el('p', { class: 'app-error-hint', innerHTML: 'We\u2019ll retry automatically. Check that the server is running (<code>npm start</code> in the steward folder).' }),
    ),
  );
}

function buildHeroCard() {
  return el('div', { id: 'hero-state-card', class: 'state-card hero-state-card', 'data-state': 'rock_bottom' },
    el('div', { class: 'card-badge-chip', id: 'card-badge-chip' }, '01'),
    el('div', { class: 'card-stage' },
      el('div', { id: 'hero-steward-mount' }),
    ),
    el('div', { class: 'card-footer', role: 'group', 'aria-labelledby': 'card-tier-gap-headline card-tier-name', 'aria-describedby': 'hero-card-footer-a11y-desc' },
      el('div', { class: 'card-footer-top' },
        el('span', { class: 'card-tier-gap-headline', id: 'card-tier-gap-headline' }, '\u2192 \u2014'),
        el('span', { class: 'card-tier-name', id: 'card-tier-name' }, 'Rock Bottom'),
      ),
      el('p', { class: 'sr-only', id: 'hero-card-footer-a11y-desc' }, 'Primary cue: dollar gap to escape your current payoff stage is the first line; stage name follows. The thin bar is only your position within this stage\u2014not breathing room or how much debt you have paid down overall.'),
      el('div', { class: 'card-footer-bar', 'aria-hidden': 'true' },
        el('div', { class: 'card-bar-track' },
          el('div', { class: 'card-bar-fill', id: 'card-bar-fill' }),
        ),
        el('span', { class: 'card-bar-inband-pct', id: 'card-bar-inband-pct' }, '0%'),
      ),
      el('span', { class: 'card-footer-debt', id: 'card-footer-debt' }, '\u2014 remaining'),
    ),
  );
}

function buildHeroSection() {
  return el('section', { class: 'hero-section', id: 'hero-section' },
    el('div', { class: 'hero-stage-column' },
      el('div', { class: 'hero-stage-frame' },
        buildHeroCard(),
      ),
    ),
    el('div', { class: 'hero-story-column' },
      el('p', { class: 'eyebrow', id: 'hero-badge' }, '01 \u2014 Rock Bottom'),
      el('h1', { id: 'hero-tier-label' }, 'Rock Bottom'),
      el('p', { class: 'hero-tier-behavior', id: 'hero-tier-behavior' }, 'Reduce debt and protect cash. Survival comes first.'),
      el('p', { class: 'hero-desc', id: 'hero-tier-copy' }, 'In the hole. The meter is running.'),
      el('p', { class: 'play-hero-foot muted' }, 'Progress and sync use the same data as other Steward shells.'),
    ),
  );
}

function buildSentinelBlock() {
  const wrap = el('div', {
    class: 'dashboard-render-sentinels',
    style: 'position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0;white-space:nowrap',
    'aria-hidden': 'true',
  });

  wrap.innerHTML = `
    <div class="board-eyebrow-row">
      <p class="board-eyebrow">Financial position</p>
      <div class="board-axis-chips" id="board-axis-chips">
        <span class="board-stability-pill board-axis-debt" id="board-debt-axis" title="Payoff stage follows debt remaining. The headline is dollars to the next payoff stage—not breathing room.">Payoff stage: —</span>
        <span class="board-stability-pill board-axis-liquidity" id="board-liquidity-pill">Breathing room: —</span>
      </div>
    </div>
    <p class="board-axes-hint" id="board-axes-hint"></p>
    <p class="board-runway-line" id="board-runway-line"></p>
    <p class="board-guard-note" id="board-guard-note" hidden></p>
    <p class="board-stability-note" id="board-stability-note"></p>

    <div class="board-primary">
      <div class="board-primary-debt">
        <span class="board-label board-label-debt">Debt remaining</span>
        <span class="board-figure board-figure-debt debt-value" id="stat-debt-remaining">—</span>
      </div>
      <div class="board-primary-rule" aria-hidden="true"></div>
      <div class="board-primary-nw">
        <span class="board-label board-label-nw">Net worth</span>
        <span class="board-figure board-figure-nw networth-value" id="stat-net-worth">—</span>
      </div>
    </div>

    <div class="board-block board-progress">
      <div class="board-progress-head">
        <div class="tier-lane">
          <span class="tier-pill" id="next-tier-current">—</span>
          <span class="tier-lane-arrow" aria-hidden="true">→</span>
          <span class="tier-pill tier-pill-target" id="next-tier-target">—</span>
        </div>
        <div class="board-tier-gap-line">
          <span class="board-tier-gap-field-label" id="board-tier-gap-label">Stage gap</span>
          <span class="board-tier-gap-headline" id="board-tier-gap-headline">—</span>
        </div>
      </div>
      <p class="progress-milestone-next progress-hint" id="progress-milestone-next" hidden></p>
      <p class="sr-only" id="command-progress-widget-a11y-desc">
        The hero card states your full escape gap in words. Here, Stage gap shows the same dollar figure only. The thin bar below is only your position inside this payoff stage—not total debt paid down or breathing room.
      </p>
      <div class="progress-bar-track progress-bar-track--command" role="progressbar" aria-labelledby="board-tier-gap-label board-tier-gap-headline" aria-describedby="command-progress-widget-a11y-desc" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="command-progress-widget">
        <div class="progress-bar-fill" id="command-progress-bar-fill"></div>
      </div>
      <p class="progress-next-move" id="progress-next-move" hidden></p>
      <p class="progress-lead" id="progress-story-lead"></p>
      <p class="progress-line" id="progress-lifetime-climb"></p>
      <p class="progress-line" id="progress-story-delta"></p>
      <p class="progress-line" id="progress-story-pace"></p>
      <p class="progress-hint progress-projection" id="progress-story-projection" hidden></p>
      <p class="progress-hint progress-projection" id="progress-story-projection-debtfree" hidden></p>
      <p class="progress-hint" id="progress-story-hint"></p>
      <p class="progress-hint" id="progress-stale-note" hidden></p>
      <p class="progress-hint" id="progress-restructure-note" hidden></p>
      <div class="climb-last-pull-summary" id="climb-last-pull-summary" hidden>
        <p class="progress-hint climb-last-pull-label">This turn</p>
        <div class="climb-last-pull-accounts" id="progress-last-pull-accounts"></div>
        <p class="progress-hint climb-last-pull-line climb-last-pull-net" id="progress-last-pull-net-line"></p>
        <p class="progress-hint climb-last-pull-line climb-last-pull-lifetime" id="progress-last-pull-lifetime-line"></p>
      </div>
      <div class="paid-row">
        <span class="paid-label"></span>
        <span class="paid-value" id="stat-debt-paid">—</span>
        <span class="paid-feedback" id="paid-down-feedback" hidden></span>
      </div>
    </div>

    <div class="board-block board-health">
      <p class="board-health-title">Breathing room &amp; cash flow</p>
      <div class="board-health-grid">
        <div class="health-cell">
          <span class="health-label">Monthly income</span>
          <span class="health-value health-in" id="stat-income">—</span>
        </div>
        <div class="health-cell">
          <span class="health-label">Monthly expenses</span>
          <span class="health-value health-out" id="stat-expenses">—</span>
        </div>
        <div class="health-cell">
          <span class="health-label">Cash / assets</span>
          <span class="health-value" id="stat-assets">—</span>
        </div>
        <div class="health-cell">
          <span class="health-label" title="Months of expenses YNAB total on-budget assets could cover (last full month of expenses). Counts investments and other non-cash balances, so it is often higher than breathing-room runway.">Asset runway (YNAB)</span>
          <span class="health-value" id="stat-months-ahead">—</span>
        </div>
      </div>
      <div class="board-health-foot">
        <div class="inv-line">
          <span class="inv-label">Investments</span>
          <span class="inv-value" id="stat-investments">—</span>
        </div>
        <p class="inv-sub" id="stat-brok-sub" hidden></p>
      </div>
    </div>
  `;

  return wrap;
}

function buildDataStrip() {
  const section = el('section', { class: 'data-strip panel dashboard-minimal-sync', 'aria-label': 'Data sync' });
  section.innerHTML = `
    <div class="data-strip-grid">
      <div class="data-chip">
        <span class="data-chip-k">YNAB last pull</span>
        <span class="data-chip-v" id="data-ynab-pulled">—</span>
      </div>
      <div class="data-chip">
        <span class="data-chip-k">Brokerage</span>
        <span class="data-chip-v" id="data-brok-pulled">—</span>
      </div>
      <div class="data-chip">
        <span class="data-chip-k">Next auto-pull</span>
        <span class="data-chip-v" id="data-next-pull">—</span>
      </div>
      <div class="data-chip data-chip-fresh">
        <span class="data-chip-k">Freshness</span>
        <span class="freshness-badge" id="freshness-badge">—</span>
      </div>
    </div>
    <div class="data-strip-actions">
      <button type="button" class="refresh-btn refresh-btn-compact" id="refresh-ynab-btn" onclick="manualRefresh('ynab')">↻ YNAB</button>
      <button type="button" class="refresh-btn refresh-btn-compact refresh-btn-secondary" id="refresh-brok-btn" onclick="manualRefresh('brokerage')">↻ Brokerage</button>
    </div>
    <p class="refresh-msg refresh-msg-compact" id="refresh-msg"></p>
    <p class="data-strip-session" id="data-session-time" hidden></p>
    <p class="data-strip-foot">Data only updates when you press refresh. Server syncs YNAB on 1st · 15th · last of month — pull manually to see it.</p>
  `;
  return section;
}

export function mountPlayShell(root) {
  root.textContent = '';

  root.appendChild(buildCommitmentScreen());
  root.appendChild(buildTopNav());
  root.appendChild(buildStartGameScreen());
  root.appendChild(buildLoadingScreen());
  root.appendChild(buildErrorScreen());

  const dashboard = el('main', { class: 'dashboard app-shell dashboard--play', id: 'dashboard-play' });
  dashboard.appendChild(buildHeroSection());
  dashboard.appendChild(buildSentinelBlock());
  dashboard.appendChild(buildDataStrip());
  dashboard.appendChild(
    el('div', { class: 'play-meta-actions' },
      el('button', { type: 'button', class: 'play-reset-btn', id: 'play-reset-btn' }, '\u21BA Reset game'),
    ),
  );

  root.appendChild(dashboard);
}
