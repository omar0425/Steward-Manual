'use strict';

import { isPlayDashboardDoc } from './shell.js';
import { stewardApiUrl, stewardPublicOriginHint, readJsonRes, readBrokerageRes } from './api.js';
import { readSessionMeta, writeSessionMeta, startPlaytimeTracking, SESSION_APP_READY_KEY } from './session.js';
import { render } from './render.js';
import { mountStartScreenSteward } from './character.js';
import { offerFirstVisitDashboardOnboarding } from './onboarding.js';
import { readPromiseMadeFlag, openCommitmentGate, initPlayResetBtn } from './commitment.js';
import { AppMode, transitionTo, isSessionResume } from './state.js';

const STARTUP_UI_DEBUG = true;

let startupBootComplete = false;

function setBootErrorMessage(message) {
  const el = document.getElementById('app-error-text');
  if (el) el.textContent = message || '';
}

function initStartGameGate() {
  const startRoot = document.getElementById('start-game-screen');
  const clockEl = document.getElementById('start-game-clock');
  const btn = document.getElementById('start-game-btn');

  const resumeAfterRefresh = isSessionResume();

  if (!startRoot || !btn) {
    transitionTo(AppMode.LOADING, 'init: no start gate');
    void load({ refresh: false }).catch(err => {
      console.error('[Steward] load() failed (no start gate)', err);
      setBootErrorMessage(err && err.message ? err.message : String(err));
      transitionTo(AppMode.ERROR, `load reject: ${err && err.message ? err.message : err}`);
    });
    return;
  }

  if (resumeAfterRefresh) {
    transitionTo(AppMode.LOADING, 'session resume (same tab)');
    void load({ refresh: false }).catch(err => {
      console.error('[Steward] load() failed (session resume)', err);
      setBootErrorMessage(err && err.message ? err.message : String(err));
      transitionTo(AppMode.ERROR, `load reject: ${err && err.message ? err.message : err}`);
    });
    return;
  }

  transitionTo(AppMode.START, 'init: start gate shown');

  mountStartScreenSteward();

  const tickClock = () => {
    if (!clockEl) return;
    clockEl.textContent = new Date().toLocaleString(undefined, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
    });
  };
  tickClock();
  const clockTimer = window.setInterval(tickClock, 1000);

  let startClickInFlight = false;

  const onStart = () => {
    if (startClickInFlight) {
      if (STARTUP_UI_DEBUG) console.debug('[Steward] ignored: Start Game click (in flight)');
      return;
    }
    startClickInFlight = true;

    window.clearInterval(clockTimer);
    btn.disabled = true;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const animDelay = reducedMotion ? 0 : 1400;

    document.body.classList.add('start-animating');

    setTimeout(() => {
      transitionTo(AppMode.LOADING, 'start button click');

      const now = new Date().toISOString();
      const meta = readSessionMeta();
      if (!meta.firstStartedAt) meta.firstStartedAt = now;
      meta.currentSessionStartedAt = now;
      meta.lastSeenAt = now;
      meta.sessionCount += 1;
      writeSessionMeta(meta);

      startPlaytimeTracking();

      void load({ refresh: false }).catch(err => {
        console.error('[Steward] load() failed after Start Game', err);
        setBootErrorMessage(err && err.message ? err.message : String(err));
        transitionTo(AppMode.ERROR, `load reject: ${err && err.message ? err.message : err}`);
      });
    }, animDelay);
  };

  btn.addEventListener('click', onStart);
}

export function initDashboardBoot() {
  initPlayResetBtn();
  const root = document.getElementById('commitment-screen');
  if (!root) {
    initStartGameGate();
    return;
  }
  if (readPromiseMadeFlag()) {
    initStartGameGate();
    return;
  }
  openCommitmentGate(() => initStartGameGate());
}

async function load(options = {}) {
  const bootCompleteBefore = startupBootComplete;
  const isDataRefresh = bootCompleteBefore && options.refresh !== false;
  const isManual = !!options.manual;

  if (!isDataRefresh && document.body && document.body.dataset.appMode === AppMode.ERROR) {
    transitionTo(AppMode.LOADING, 'retry after error');
  }

  if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
    const txt = document.querySelector('.loading-text');
    if (txt) {
      txt.textContent = `This page must be served by Steward. Run npm start in the steward folder — then open ${stewardPublicOriginHint()}/ (not a local file). The file:// protocol cannot reach the API.`;
    }
    const fileMsg = `Open this app via ${stewardPublicOriginHint()}/ after npm start in the steward folder. The file:// protocol cannot reach the API.`;
    if (!isDataRefresh) {
      setBootErrorMessage(fileMsg);
      transitionTo(AppMode.ERROR, 'file: protocol');
    }
    return;
  }

  try {
    const fetchWithTimeout = (url, ms = 12000) => {
      const ctrl = new AbortController();
      const tid = setTimeout(() => ctrl.abort(), ms);
      return fetch(url, { signal: ctrl.signal }).finally(() => clearTimeout(tid));
    };
    const [statusRes, snapsRes, brokRes] = await Promise.all([
      fetchWithTimeout(stewardApiUrl('/api/status?debugDebtSync=1')),
      fetchWithTimeout(stewardApiUrl('/api/snapshots')),
      fetchWithTimeout(stewardApiUrl('/api/brokerage')),
    ]);
    const [status, snapshots, brokerage] = await Promise.all([
      readJsonRes(statusRes, '/api/status'),
      readJsonRes(snapsRes, '/api/snapshots'),
      readBrokerageRes(brokRes),
    ]);

    if (!status.ready) {
      const txt = document.querySelector('.loading-text');
      if (txt) {
        if (status.lastError) {
          txt.textContent = `YNAB: ${status.lastError}`;
        } else {
          txt.textContent = status.message || 'Pulling your financial data\u2026';
        }
      }
      if (STARTUP_UI_DEBUG) console.debug(`[Steward] poll: status not ready \u2192 retry in 3s (dataRefresh=${isDataRefresh})`);
      if (isPlayDashboardDoc() && startupBootComplete && !isManual) return;
      window.setTimeout(() => load({ refresh: isDataRefresh, manual: isManual }), 3000);
      return;
    }

    render(status, snapshots, brokerage);

    if (!isDataRefresh) {
      startupBootComplete = true;
      transitionTo(AppMode.READY, 'load success');
      window.setTimeout(() => {
        if (!isPlayDashboardDoc()) offerFirstVisitDashboardOnboarding();
      }, 480);
    }
  } catch (err) {
    console.error('Failed to load status:', err);
    const detail = err && err.message && err.message.length < 220 ? err.message : '';
    const userLine = detail
      ? `Could not load dashboard. ${detail}`
      : `Could not reach the Steward server. Run npm start in the steward folder \u2014 then open ${stewardPublicOriginHint()}/`;

    if (!isDataRefresh) {
      setBootErrorMessage(userLine);
      transitionTo(AppMode.ERROR, `load failure: ${err && err.message ? err.message : err}`);
    }

    const txt = document.querySelector('.loading-text');
    if (txt) txt.textContent = userLine;

    if (STARTUP_UI_DEBUG) console.debug(`[Steward] load retry in 5s (dataRefresh=${isDataRefresh})`);
    if (isPlayDashboardDoc() && startupBootComplete && !isManual) return;
    window.setTimeout(() => load({ refresh: isDataRefresh, manual: isManual }), 5000);
  }
}

/* \u2500\u2500 Manual refresh \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
export async function manualRefresh(source) {
  const btn = document.getElementById(`refresh-${source === 'ynab' ? 'ynab' : 'brok'}-btn`);
  const msg = document.getElementById('refresh-msg');
  if (!btn || !msg) return;
  btn.disabled = true;
  msg.textContent = `Refreshing ${source.toUpperCase()}\u2026`;

  try {
    const res = await fetch(stewardApiUrl(`/api/refresh/${source}`), { method: 'POST' });
    const data = await res.json().catch(() => ({}));
    const succeeded = res.ok && data.ok !== false && !data.error;
    if (succeeded) {
      msg.textContent = data.message || 'Done.';
      window.setTimeout(() => load({ refresh: true, manual: true }), 2000);
    } else {
      msg.textContent = data.error || data.message || 'Error refreshing.';
    }
  } catch (err) {
    msg.textContent = 'Network error.';
  }

  setTimeout(() => { btn.disabled = false; }, 3000);
}
